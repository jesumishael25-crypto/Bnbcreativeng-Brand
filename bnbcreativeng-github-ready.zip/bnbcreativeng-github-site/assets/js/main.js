const menuToggle=document.getElementById('menuToggle'),navLinks=document.getElementById('navLinks');
menuToggle.addEventListener('click',()=>{const open=navLinks.classList.toggle('open');menuToggle.setAttribute('aria-expanded',String(open));menuToggle.textContent=open?'×':'☰'});
navLinks.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{navLinks.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.textContent='☰'}));
const filters=document.querySelectorAll('.filter'),workCards=document.querySelectorAll('.work-card');
function setFilter(category){filters.forEach(b=>b.classList.toggle('active',b.dataset.filter===category));workCards.forEach(card=>{card.style.display=(category==='All'||card.dataset.category===category)?'block':'none'})}
filters.forEach(b=>b.addEventListener('click',()=>setFilter(b.dataset.filter)));
document.querySelectorAll('[data-filter-link]').forEach(a=>a.addEventListener('click',()=>setFilter(a.dataset.filterLink)));
const lightbox=document.getElementById('lightbox'),lightboxImage=document.getElementById('lightboxImage');
document.querySelectorAll('.work-card img').forEach(img=>img.addEventListener('click',()=>{lightboxImage.src=img.src;lightboxImage.alt=img.alt;lightbox.classList.add('open');document.body.style.overflow='hidden'}));
function closeLightbox(){lightbox.classList.remove('open');document.body.style.overflow=''}
document.getElementById('lightboxClose').addEventListener('click',closeLightbox);lightbox.addEventListener('click',e=>{if(e.target===lightbox)closeLightbox()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeLightbox()});
document.getElementById('contactForm').addEventListener('submit',e=>{e.preventDefault();const name=document.getElementById('name').value.trim(),phone=document.getElementById('phone').value.trim(),subject=document.getElementById('subject').value,message=document.getElementById('message').value.trim();const text=`Hello BNBCREATIVENG, my name is ${name}.${phone?' My phone number is '+phone+'.':''}\nEnquiry: ${subject}\nMessage: ${message}\nI found you through your website.`;document.getElementById('formToast').classList.add('show');window.open('https://wa.me/2348032310582?text='+encodeURIComponent(text),'_blank','noopener')});
document.getElementById('year').textContent=new Date().getFullYear();
const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
