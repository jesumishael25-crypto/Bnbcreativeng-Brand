# Brand images

Add your own BNBCREATIVENG photos in this folder. Then update the relevant `src` attributes in `index.html` and image URLs in `assets/css/style.css` (the hero and delivery background).

Recommended filenames: `hero.jpg`, `about.jpg`, `female-outfits-01.jpg`, `auto-gele-01.jpg`, `beadworks-01.jpg`, `bags-01.jpg`, `turbans-01.jpg`, `fascinators-01.jpg`, `hats-01.jpg`.

The current site uses temporary remote inspiration photos. Replace them with photos you have permission to use before launch.
